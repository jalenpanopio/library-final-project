<?php

include "connect.php"
$sql = SELECT AccountID, email, password FROM login_table WHERE "%gmail%";

?>